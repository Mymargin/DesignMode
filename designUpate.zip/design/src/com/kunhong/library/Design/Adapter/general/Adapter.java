package com.kunhong.library.Design.Adapter.general;

/**
 * ��������ɫ
 * @author lyq
 *
 */
public class Adapter extends Adapee implements Target{

	@Override
	public void request() {
		// TODO Auto-generated method stub
		super.doSomeThing();
	}
	
}
