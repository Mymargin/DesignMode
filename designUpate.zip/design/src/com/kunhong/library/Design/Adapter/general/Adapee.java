package com.kunhong.library.Design.Adapter.general;

/**
 * Դ��ɫ
 * @author lyq
 *
 */
public class Adapee {
	//ԭ�е�ҵ���߼�
	public void doSomeThing(){
		
	}
}
