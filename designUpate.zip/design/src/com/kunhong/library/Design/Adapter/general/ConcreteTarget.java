package com.kunhong.library.Design.Adapter.general;

public class ConcreteTarget implements Target{

	@Override
	public void request() {
		// TODO Auto-generated method stub
		
	}

}
