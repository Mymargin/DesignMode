package com.kunhong.library.Design.TemplateMethod.general;

/**
 * ����ģ����
 * @author lyq
 *
 */
public class ConcreteClass1 extends AbstractClass{

	@Override
	protected void doSomething() {
		// TODO Auto-generated method stub
		
	}

	@Override
	protected void doAnything() {
		// TODO Auto-generated method stub
		
	}

}
