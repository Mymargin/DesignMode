package com.kunhong.library.Design.ChainOfResponsibility.general;

/**
 * ����ĵȼ�
 * @author lyq
 *
 */
public class Request {
	//����ĵȼ�
	public Level getRequestLevel(){
		return null;
	}
}
