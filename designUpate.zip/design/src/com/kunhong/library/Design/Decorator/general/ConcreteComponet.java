package com.kunhong.library.Design.Decorator.general;

/**
 * ���幹��
 * @author lyq
 *
 */
public class ConcreteComponet extends Component{

	//����ʵ��
	@Override
	public void operate() {
		// TODO Auto-generated method stub
		
	}

}
