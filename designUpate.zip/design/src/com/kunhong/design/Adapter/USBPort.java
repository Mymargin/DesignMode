package com.kunhong.design.Adapter;

/**
 * USB�ӿڣ�U��
 * 
 */
public interface USBPort {
	public void workWithUSB();
}
