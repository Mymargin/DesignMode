package com.kunhong.design.Observer;

/**
 * ����۲��߽�ɫ
 * @author lyq
 *
 */
public interface AbstractWatcher {
	
	public void update();

}
