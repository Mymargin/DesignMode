package com.kunhong.design.Visitor;

public interface Person {
	void accept(Visitor visitor);
}
