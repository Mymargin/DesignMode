package com.kunhong.design.Visitor;

public interface Visitor {  
    public void visit(Man man);  
    public void visit(Woman girl);  
}  