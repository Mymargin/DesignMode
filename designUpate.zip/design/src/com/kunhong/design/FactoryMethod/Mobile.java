package com.kunhong.design.FactoryMethod;

public interface Mobile {
	public void call();
}
