package com.kunhong.design.FactoryMethod;

public interface MobileFactory{
    public Mobile produceMobile();
}
