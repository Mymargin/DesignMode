package com.kunhong.design.Iterator;

public interface Iterator {
	public Object next();
	public boolean hasNext();
}

	

