package com.kunhong.design.Bridge;

public interface Drawing {
	void draw();
}
