package com.kunhong.design.Bridge;

public class Drawing2 implements Drawing{

	@Override
	public void draw() {
		System.out.println("ִ�л��Ʒ���2");
		
	}

}
