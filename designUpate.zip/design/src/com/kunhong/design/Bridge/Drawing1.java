package com.kunhong.design.Bridge;

public class Drawing1 implements Drawing{

	@Override
	public void draw() {
		System.out.println("ִ�л��Ʒ���1");
		
	}

}
