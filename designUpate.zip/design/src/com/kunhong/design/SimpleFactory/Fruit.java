package com.kunhong.design.SimpleFactory;

public interface Fruit {
	/**
	 *  ����
	 */
	void grow();

	/**
	 *  �ջ�
	 */
	void harvest();

	/**
	 *  ��ֲ
	 */
	void plant();
}
