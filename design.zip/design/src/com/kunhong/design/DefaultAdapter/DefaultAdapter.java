package com.kunhong.design.DefaultAdapter;

/** 
* Created by IntelliJ IDEA. 
* Ĭ����������ɫ��Ĭ��ʵ�� 
*/ 
public class DefaultAdapter implements Target { 

    public void f1() { 
    } 

    public void f2() { 
    } 

    public void f3() { 
    } 

    public void f4() { 
    } 

    public void f5() { 
    } 
}
