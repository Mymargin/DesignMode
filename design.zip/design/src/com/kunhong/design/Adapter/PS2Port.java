package com.kunhong.design.Adapter;

/**
 * PS2�ӿڣ�Բ��
 *
 */
public interface PS2Port {
	public void workWithPS2();
}

