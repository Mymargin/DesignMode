package com.kunhong.design.State;

public interface MoodState{
    public void doSomething();
    public void changeState();
}
