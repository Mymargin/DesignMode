package com.kunhong.design.FactoryMethod;

public class Motorola implements Mobile {
	public void call() {
		System.out.println("Motorola producted");
	}
}
