package com.kunhong.design.FactoryMethod;

public class Nokia implements Mobile{
    public void call(){
           System.out.println("Nokia producted");
    }
}