package com.kunhong.design.Bridge;

public class Rectangle implements Shape{

	@Override
	public void doDraw() {
		// TODO Auto-generated method stub
		
	}

}
