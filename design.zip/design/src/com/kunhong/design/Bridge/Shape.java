package com.kunhong.design.Bridge;

public interface Shape{
    void doDraw();
}
